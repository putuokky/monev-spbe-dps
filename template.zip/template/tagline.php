<?php
class tagline
{
    function title_front()
    {
        echo 'Sistem Pemerintahan Berbasis Elektronik';
    }

    function sidetitle()
    {
        echo 'SPBE';
    }

    function kota()
    {
        echo 'Kota Denpasar';
    }

    function pemkot()
    {
        echo 'Pemerintahan Kota Denpasar';
    }

    function develop()
    {
        echo 'Development by Tim Pengembangan Aplikasi Kominfo Denpasar';
    }
}
