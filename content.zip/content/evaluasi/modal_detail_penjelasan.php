<div class="modal fade" id="modalDetailPenjelasan-<?= $id; ?>" tabindex="-1" role="dialog" aria-labelledby="modalDetailPenjelasanLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalDetailPenjelasanLabel">Penjelasan <?php include 'template/title.php'; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <table class="table table-striped table-bordered">
          <tbody>
            <tr>
              <th>Penjelasan Evaluasi</th>
              <th>Penjelasan Level</th>
            </tr>
            <tr>
              <td>
                <?= $penjelasan_evaluasi; ?>
              </td>
              <td>
              <?= $namalevel." - ".$penjelasan_level; ?>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>