<?php
include 'model/model_domain.php';
include 'model/model_indikator.php';
include 'model/m_aplikasi.php';
include 'model/m_start_up_digi.php';
