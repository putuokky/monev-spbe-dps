<li class="nav-item">
  <a class="nav-link" href="#" data-toggle="collapse" data-target="#collapsePagesMaster" aria-expanded="true" aria-controls="collapsePagesMaster" id="master">
    <i class="fas fa-fw fa-archway"></i>
    <span>Master SPBE</span>
  </a>
  <div id="collapsePagesMaster" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Sub Menu:</h6>
      <a class="collapse-item" href="?page=indeks" id="indeks">Indeks</a>
      <a class="collapse-item" href="?page=domain" id="domain">Domain</a>
      <a class="collapse-item" href="?page=aspek" id="aspek">Aspek</a>
      <a class="collapse-item" href="?page=indikator" id="indikator">Indikator</a>
      <a class="collapse-item" href="?page=pertanyaan" id="pertanyaan">Pertanyaan</a>
      <a class="collapse-item" href="?page=level" id="level">Level</a>
      <a class="collapse-item" href="?page=feedbackopd" id="feedbackopd">Feedback OPD</a>
    </div>
  </div>
</li>