<li class="nav-item">
  <a class="nav-link" href="#" data-toggle="collapse" data-target="#collapsePagesMasterApps" aria-expanded="true" aria-controls="collapsePagesMasterApps" id="master">
    <i class="fas fa-fw fa-archway"></i>
    <span>Master Aplikasi</span>
  </a>
  <div id="collapsePagesMasterApps" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Sub Menu:</h6>
      <a class="collapse-item" href="?page=katapps" id="katapps">Kategori Aplikasi</a>
      <a class="collapse-item" href="?page=katdb" id="katdb">Kategori Database</a>
      <a class="collapse-item" href="?page=katmedia" id="katmedia">Kategori Media</a>
    </div>
  </div>
</li>