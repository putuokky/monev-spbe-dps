<li class="nav-item">
  <a class="nav-link" href="#" data-toggle="collapse" data-target="#collapsePagesMasterInbis" aria-expanded="true" aria-controls="collapsePagesMasterInbis" id="master">
    <i class="fas fa-fw fa-archway"></i>
    <span>Master Inbis</span>
  </a>
  <div id="collapsePagesMasterInbis" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
    <div class="bg-white py-2 collapse-inner rounded">
      <h6 class="collapse-header">Sub Menu:</h6>
      <a class="collapse-item" href="?page=inbis" id="inbis">Kategori Inbis</a>
    </div>
  </div>
</li>